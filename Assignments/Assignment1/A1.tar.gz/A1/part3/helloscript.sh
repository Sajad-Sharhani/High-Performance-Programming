echo Hej hej
echo Hej hej
echo Hej hej
echo Hej hej